package sudoku;

public class Board
 {

 protected String [][] board;
 protected boolean [][] variance;
 private int rowAmount;
 private int collumnAmount;
 

 
 public Board
(String [] insertedValues) {
  //initiailize board (number of blocks, etc)
  //initialize board and variance matrices
 }
 
 
//This class pertains to the matrices that hold the values, and will determine the number of valid values necessary for the algorithms